package dk.itu.mario.engine.sonar;

public interface SoundSource
{
	public float getX(float alpha);
	public float getY(float alpha);
}