package dk.itu.mario.engine.sonar.sample;

public class SonarSample
{
    public final float[] buf;
    public final float rate;
    
    public SonarSample(float[] buf, float rate)
    {
        this.buf = buf;
        this.rate = rate;
    }
}